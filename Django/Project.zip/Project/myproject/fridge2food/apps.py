from django.apps import AppConfig


class Fridge2FoodConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "fridge2food"
